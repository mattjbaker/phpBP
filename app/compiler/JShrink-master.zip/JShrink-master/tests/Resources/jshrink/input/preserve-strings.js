var test = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

var test = "abcdefg\"hijklmnopqrst\"uvwxyzABCDEFGHIJKLMNO\"PQRSTUVWXYZ0123456789";



var test = "abcdefghij\
klmnopqrstuvwxyzABCD \
EFGHIJKLMNOPQRSTUVWXYZ0123456789";