"use strict";
var foo=22;